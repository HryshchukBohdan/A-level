<?php

$array = [
            [
                'text' => 'Текст красного цвета',
                'cells' => '1,2,4,5',
                'align' => 'center',
                'valign' => 'middle',
                'color' => 'FF0000',
                'bgcolor' => '0000FF'
            ],
            [
                'text' => 'Текст зеленого цвета',
                'cells' => '8,9',
                'align' => 'right',
                'valign' => 'bottom',
                'color' => '00FF00',
                'bgcolor' => 'RED'
            ]
        ];

function html_create($array = [])
{
    $width_height_elem = 200; //200px
    $position = [1,2,3,4,5,6,7,8,9];
    $mess_error = 'error';

    function er($val) {
        if ($val > 1) {
            echo $mess_error;
            die();
        } else {
            return $val;
        }
    }

    echo "<html> \n <head> \n <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> \n <title>Test!</title> \n </head> \n <body>";

    echo "<div style='width: 600px; height: 600px;' >";
    foreach ($array as &$value)
    {
        $cells = explode(',',$value['cells']);
        arsort($cells, SORT_NUMERIC);

        $first_flag = 0;
        $second_flag = 0;
        $third_flag = 0;
        $width_elem = 0;

        foreach ($cells as $cell) {

            if ((($cell - 9) <= 0 and (($cell - 9) >= -2))) {
                $value['pos'] = $cell;
                $pos_not_free[] = $cell + 1;
                $third_flag = $width_height_elem; //height one block
                $width_elem += $width_height_elem;
            } elseif ((($cell - 6) <= 0 and (($cell - 6) >= -2))) {
                $value['pos'] = $cell;
                $pos_not_free[] = $cell + 1;
                $second_flag = $width_height_elem;
                $width_elem += $width_height_elem;
            } elseif (($cell - 3) <= 0) {
                $value['pos'] = $cell;
                $pos_not_free[] = $cell + 1;
                $first_flag = $width_height_elem;
                $width_elem += $width_height_elem;
            }
        }

        $value['flag'] = $first_flag + $second_flag + $third_flag;
        $value['width_flag'] = ($width_elem/($value['flag']/$width_height_elem))-2; // - border line
        $value['flag'] = $value['flag'] - 2;
        $pos_unique = array_count_values($pos_not_free);

        array_map('er', $pos_unique);

        $position = array_diff($position, $pos_not_free);
    }
    unset($value);

    foreach ($array as $value) {
        foreach ($position as $pos) {
            if ($pos >= (int)$value['pos']) {
                echo "<div style='display: inline-block; float: left; border: 1px solid black;'> 
                        <span style=\"vertical-align: $value[valign];
                                    text-align: $value[align];
                                    height: $value[flag]px;
                                    width: $value[width_flag];
                                    display: table-cell;
                                    background-color: $value[bgcolor];
                                    color: $value[color]; \">
                            $value[text]
                        </span>
                      </div> \n";
                break;
            } else {
                echo "<div style='display: inline-block; float: left; border: 1px solid black; height: 198px; width: 198px;'></div> \n";
            }
        }
    }
    echo "</div> \n </body> \n </html>";
}

html_create($array);
